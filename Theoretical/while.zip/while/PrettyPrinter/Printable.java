package PrettyPrinter;

public interface Printable {
  public void pretty(PrettyPrinter pp);
}
